package com.example.covidtracker.data;

import java.util.ArrayList;

public class Trip {
    public String country;
    public int infected;
    public int deaths;
    public int vax;

    public Trip() {
        heTrippin(country, infected, deaths, vax);
    }



    public Trip heTrippin(String country, int infected, int deaths, int vax) {
        this.country=country;
        this.infected=infected;
        this.deaths=deaths;
        this.vax=vax;
        return null;
    }

    public String getCountry(){
        return country;
    }

    public void setCountry() {
        this.country = "United States of America";
    }

    public int getInfected(){
        return infected;
    }

    public void setInfected(){
        this.infected = 79411749;
    }

    public int getDeaths() {
        return deaths;
    }

    public void setDeaths() {
        this.deaths = 966218;
    }

    public int getVax() {
        return vax;
    }

    public void setVax() {
        this.vax = 216587984;
    }

}
