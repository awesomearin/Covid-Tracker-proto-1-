package com.example.covidtracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.covidtracker.data.Trip;
import com.example.covidtracker.databinding.FragmentFirstBinding;

import java.util.ArrayList;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;


    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }


    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Trip t = new Trip();
        ArrayList<String> countryArrayList= new ArrayList<String>();
            countryArrayList.set(0, "United States");
        ArrayList<Integer> infArrayList = new ArrayList<Integer>();
            infArrayList.set(0, 696969);
        ArrayList<Integer> dedArrayList = new ArrayList<Integer>();
            dedArrayList.set(0, 420);
        ArrayList<Integer> vaxArrayList = new ArrayList<Integer>();
            vaxArrayList.set(0, 69);

        binding.newtripButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}