package com.example.covidtracker;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.covidtracker.databinding.FragmentSecondBinding;

import java.util.ArrayList;

public class SecondFragment extends Fragment {

    public interface MyInterfcae {
        void showTextView();
    }

    private FragmentSecondBinding binding;
    private ArrayList<Object> bungus = new ArrayList<Object>();

    
    TextView infected, ded, vaxxed;
    private int infects;
    private int deaths;
    private int vax;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView infec = (TextView) getActivity().findViewById(R.id.tripname);
        TextView deth = getActivity().findViewById(R.id.deaths);
        TextView vexy = getActivity().findViewById(R.id.vaxxed);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle   savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_second, container, false);
        binding = FragmentSecondBinding.inflate(inflater, container, false);


        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });

        binding.confirmButton.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            NavHostFragment.findNavController(SecondFragment.this)
                    .navigate(R.id.action_second_to_display);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}